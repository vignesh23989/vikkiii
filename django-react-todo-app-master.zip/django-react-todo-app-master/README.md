# django-react-todo-app

Source Code of Todo App Tutorial for this [YouTube video](https://www.youtube.com/watch?v=OSYAjTG46EI)

<img src="./thumbnail.png" width="320" height="180" />
